const i = k => chrome.i18n.getMessage(k);
const s = chrome.storage.local;
const EXAMPLE_URL = 'https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=salt+and+pepper+shakers+novelty';

function track(category, action, label, value) {
    // chrome.runtime.sendMessage({action: 6, event: {category: category, action: action, label: label, value: value}});
}

chrome.tabs.query({currentWindow: true, active: true}, function (tabs) {
    const tab = tabs[0];
    const url = tab.url;
    //track("Extension", "open");
    s.get(['ready'], res => {
        const el = document.querySelector('h2');
        if (/(www|smile)\.amazon\.[a-z.]+/i.test(url)) {
            if (res.ready) {
                const port = chrome.tabs.connect(tab.id, {name: "amazon-scout-pro"});
                port.postMessage({action: "toggle-popup", url: url, tabId: tab.id});
                window.close();
            } else {
                track('Error', 'not ready');
                el.innerHTML = i('pageLoading');
                s.set({"auto-open": {}});
            }
        } else {
            chrome.storage.local.get('state', result => {
                const state = result.state;
                if (state) {
                    let url;
                    try {
                        url = Object.keys(state).reduce((s1, s2) => state[s1].time > state[s2].time ? s1 : s2)
                    } catch (e) {
                        url = EXAMPLE_URL;
                    }
                    s.set({"auto-open": {}});
                    chrome.tabs.update(tab.id, {url});
                    window.close();
                } else {
                    track("Error", "wrong url");
                    el.innerHTML = i('wrongPage');
                    s.set({"auto-open": {}});
                    chrome.tabs.update(tab.id, {url: EXAMPLE_URL});
                }
            });
        }
    });
    return false;
});

